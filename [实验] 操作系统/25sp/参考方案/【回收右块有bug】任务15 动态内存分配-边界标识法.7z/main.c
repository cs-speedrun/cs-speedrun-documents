#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#define MAX_SIZE 1000
#define ALLOC_MIN_SIZE 10

#define RED FOREGROUND_RED
#define GREEN FOREGROUND_GREEN
#define BLUE FOREGROUND_BLUE

typedef struct Bound {
    struct Bound* preLink;
    struct Bound* upLink;
    int tag;
    int size;
    struct Bound* nextLink;
}* Space;

#define FOOT_LOC(p) ((Space)((char*)(p) + (p)->size + sizeof(struct Bound)))
#define HEAD_LOC(p) ((Space)((char*)(p) - sizeof(struct Bound) - ((Space)((char*)(p) - sizeof(struct Bound)))->size))

void initSpace(Space* freeSpace, Space* pav);
Space allocBoundTagNextFit(Space* pav, int size);
Space allocBoundTagBestFit(Space* pav, int size);
void reclaimBoundTag(Space* pav, Space sp);
void SetColor(int color);
void print(Space s);
void printSpace(Space pav);

Space userSpace[MAX_SIZE] = { NULL };
int usCount = 0;

void initSpace(Space* freeSpace, Space* pav) {
    *freeSpace = (Space)malloc((MAX_SIZE + 2) * sizeof(struct Bound));
    Space head = *freeSpace;
    head->tag = 1;
    head++;
    head->tag = 0;
    head->preLink = head->nextLink = head;
    head->size = MAX_SIZE;
    *pav = head;
    Space foot = FOOT_LOC(head);
    foot->tag = 0;
    foot->upLink = head;
    foot++;
    foot->tag = 1;
    printf("初始化完成，初始空闲空间：0x%lx\n", (unsigned long)head);
}

Space allocBoundTagNextFit(Space* pav, int size) {
    Space p = *pav;
    if (p == NULL) return NULL;
    Space start = p;

    do {
        if (p->size >= size) {
            break;
        }
        p = p->nextLink;
    } while (p != start);

    if (p == start && p->size < size) {
        return NULL; // No suitable block found
    }

    *pav = p->nextLink;

    if (p->size - size > ALLOC_MIN_SIZE) {
        p->size -= size;
        Space foot = FOOT_LOC(p);
        foot->upLink = p;
        foot->tag = 0;
        p = (Space)((char*)foot + sizeof(struct Bound));
        p->size = size;
        foot = FOOT_LOC(p);
        p->tag = foot->tag = 1;
        foot->upLink = p;
    } else {
        if (p == *pav) {
            *pav = NULL;
            p->tag = 1;
        } else {
            Space foot = FOOT_LOC(p);
            foot->tag = p->tag = 1;
            p->preLink->nextLink = p->nextLink;
            p->nextLink->preLink = p->preLink;
        }
    }

    userSpace[usCount++] = p;
    printf("分配内存块，首地址：0x%lx，大小：%d\n", (unsigned long)p, size);
    return p;
}

Space allocBoundTagBestFit(Space* pav, int size) {
    Space p = *pav;
    if (p == NULL) return NULL;
    Space bestFit = NULL;

    do {
        if (p->size >= size && (bestFit == NULL || p->size < bestFit->size)) {
            bestFit = p;
        }
        p = p->nextLink;
    } while (p != *pav);

    if (bestFit == NULL) {
        return NULL; // No suitable block found
    }

    *pav = bestFit->nextLink;

    if (bestFit->size - size > ALLOC_MIN_SIZE) {
        bestFit->size -= size;
        Space foot = FOOT_LOC(bestFit);
        foot->upLink = bestFit;
        foot->tag = 0;
        bestFit = (Space)((char*)foot + sizeof(struct Bound));
        bestFit->size = size;
        foot = FOOT_LOC(bestFit);
        bestFit->tag = foot->tag = 1;
        foot->upLink = bestFit;
    } else {
        if (bestFit == *pav) {
            *pav = NULL;
            bestFit->tag = 1;
        } else {
            Space foot = FOOT_LOC(bestFit);
            foot->tag = bestFit->tag = 1;
            bestFit->preLink->nextLink = bestFit->nextLink;
            bestFit->nextLink->preLink = bestFit->preLink;
        }
    }

    userSpace[usCount++] = bestFit;
    printf("分配内存块，首地址：0x%lx，大小：%d\n", (unsigned long)bestFit, size);
    return bestFit;
}

void reclaimBoundTag(Space* pav, Space sp) {
    Space pre = NULL;
    Space next = NULL;
    Space foot = NULL;
    int pTag = -1;
    int nTag = -1;
    int i = 0;

    printf("开始回收内存块，首地址：0x%lx\n", (unsigned long)sp);

    if (*pav != NULL) {
        pre = HEAD_LOC(sp);
        if (pre != sp) pTag = pre->tag; // Make sure not to use the same block as pre
        next = (Space)((char*)sp + sizeof(struct Bound) + sp->size);
        if (next != sp) nTag = next->tag; // Make sure not to use the same block as next
    }

    printf("pre: 0x%lx, pTag: %d, next: 0x%lx, nTag: %d\n", (unsigned long)pre, pTag, (unsigned long)next, nTag);

    if ((*pav != NULL && pTag == 1 && nTag == 1) || *pav == NULL) {
        foot = FOOT_LOC(sp);
        foot->tag = sp->tag = 0;
        if (*pav == NULL) {
            *pav = sp->preLink = sp->nextLink = sp;
        } else {
            sp->nextLink = *pav;
            sp->preLink = (*pav)->preLink;
            (*pav)->preLink = sp;
            sp->preLink->nextLink = sp;
            *pav = sp;
        }
    } else if (pTag == 0 && nTag == 1) {
        pre->size += sp->size + sizeof(struct Bound);
        foot = FOOT_LOC(pre);
        foot->tag = 0;
        foot->upLink = pre;
    } else if (pTag == 1 && nTag == 0) {
        if (*pav == next) {
            *pav = sp;
        }
        sp->preLink = next->preLink;
        sp->nextLink = next->nextLink;
        if (next->preLink) next->preLink->nextLink = sp;
        if (next->nextLink) next->nextLink->preLink = sp;
        sp->size += next->size + sizeof(struct Bound);
        foot = FOOT_LOC(sp);
        sp->tag = foot->tag = 0;
        foot->upLink = sp;
    } else if (pTag == 0 && nTag == 0) {
        pre->size += sp->size + next->size + 2 * sizeof(struct Bound);
        if (pre->nextLink) pre->nextLink = next->nextLink;
        if (next->nextLink) next->nextLink->preLink = pre;
        foot = FOOT_LOC(pre);
        foot->tag = 0;
        foot->upLink = pre;
    }

    for (i = 0; i < usCount; i++) {
        if (sp == userSpace[i]) {
            userSpace[i] = NULL;
        }
    }

    printf("回收内存块完成，首地址：0x%lx\n", (unsigned long)sp);
}

void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
        FOREGROUND_INTENSITY | color);
}

void print(Space s) {
    printf("0x%0lx    %6d\t%10d           0x%0lx  0x%0lx\n", (unsigned long)s, s->size, s->tag, (unsigned long)s->preLink, (unsigned long)s->nextLink);
}

void printSpace(Space pav) {
    SetColor(RED | GREEN | BLUE);
    printf("空间首地址  空间大小  块标志(0:空闲,1:占用)  前驱地址  后继地址\n");
    SetColor(GREEN);
    int i = 0;
    Space p = NULL, us = NULL;

    if (pav != NULL) {
        p = pav;
        print(p);
        for (p = p->nextLink; p != pav; p = p->nextLink) {
            print(p);
            i++;
        }
    }
    for (i = 0; i < usCount; i++) {
        us = userSpace[i];
        if (us) {
            printf("0x%0lx    %6d\t%10d\t\n", (unsigned long)us, us->size, us->tag);
        }
    }
}

int main(int argc, char* argv[])
{
    Space freeSpace = NULL, pav = NULL;
    initSpace(&freeSpace, &pav);
    int item = 0, i = 0, algorithm = 0;
    unsigned long start = 0;
    unsigned long joblength;
    Space us = NULL;

    while (1)
    {
        SetColor(RED | BLUE | GREEN);
        printf("选择功能项：(0-退出  1-分配内存  2-回收内存  3-显示内存)：");
        scanf("%d", &item);
        switch (item)
        {
        case 0:
            exit(0);
        case 1:
            SetColor(RED | GREEN);
            printf("所需内存长度：");
            scanf("%*c%ld", &joblength);
            printf("选择分配算法：(0-循环首次适应  1-最佳适应)：");
            scanf("%d", &algorithm);
            if (algorithm == 0) {
                us = allocBoundTagNextFit(&pav, joblength);
            } else if (algorithm == 1) {
                us = allocBoundTagBestFit(&pav, joblength);
            }
            if (us != NULL) {
                printf("分配成功，首地址：0x%lx\n", (unsigned long)us);
            } else {
                printf("分配失败\n");
            }
            break;
        case 2:
            SetColor(RED | BLUE);
            printf("输入要回收分区的首地址：");
            scanf("%lx", &start);
            for (i = 0; i < usCount; i++) {
                us = userSpace[i];
                if ((unsigned long)us == start) {
                    reclaimBoundTag(&pav, us);
                    break;
                }
            }
            if (i == usCount)
            {
                SetColor(RED);
                printf("输入要回收分区的首地址不符合要求\n");
            }
            if (pav && pav->size == MAX_SIZE) {
                usCount = 0;
            }
            break;
        case 3:
            printSpace(pav);
            break;
        default:
            printf("没有该选项\n");
        }
    }

    return 0;
}
