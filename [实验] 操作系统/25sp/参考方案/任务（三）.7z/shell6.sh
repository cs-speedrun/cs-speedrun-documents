function Mul()
{
    let i=$1*$2
    return $i
}
Mul $1 $2
a=$?
echo $a