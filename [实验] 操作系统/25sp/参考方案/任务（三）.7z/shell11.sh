i=1
while  [  $i  -lt  6  ]
do
	j=0
	str=""
	while  [  $j  -lt  $i  ]
	do
		str=”$str  `echo a`”
		let j=$j+1
	done
	echo $str
	let i=$i+1
done
