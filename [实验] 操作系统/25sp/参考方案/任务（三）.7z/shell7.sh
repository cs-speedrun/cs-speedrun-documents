if  [  -f  $1  ]
then echo File exist.
else echo Can not find file.
fi