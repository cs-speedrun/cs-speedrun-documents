#print hello world
echo hello world
echo `echo command`