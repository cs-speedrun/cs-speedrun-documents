a=1
echo $a
b=" hello world"
echo $b