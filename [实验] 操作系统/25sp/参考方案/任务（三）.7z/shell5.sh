let k=$1+$2
echo $k