echo $#
echo $?