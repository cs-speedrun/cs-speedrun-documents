i=0
while  [  $i  -lt  6  ]
do
echo $i
let i=$i+1
done