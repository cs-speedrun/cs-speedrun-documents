case  $#  in
0)  echo  0 argument;;
1)  echo  1 argument ;;
2)  echo  2 arguments;;
*)  echo  more than 2arguments;;
esac