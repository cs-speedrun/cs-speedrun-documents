echo please input data	
read a
echo $a