# 🐧 25sp Linux 操作系统课程作业 | HeZzz/9¾

> 仅代表 2025年春季学期的课程内容，可能会有变动。

本课程属于 `专业选修课程`，课程结课方式为考查，即不需要考试，只需要交两个报告。我不好说签到的严格程度，但是建议选（有没有懂的


## 📁 内容

```bash
.
├── ChatCpp/                  # 大作业核心代码，具体请看 `ChatCpp/README.md`
│
├── 作业要求.docx             # Linux操作系统作业要求文档
├── 综合报告要求.docx         # Linux操作系统综合报告要求文档
├── 作业实现.docx             # Linux操作系统作业实现文档
├── 综合报告实现.docx         # Linux操作系统综合报告文档
│
├── check_statue.sh           # 系统状态监控脚本，作业的一部分
├── 成绩截图.png              # 课程成绩截图
└── README.md                 # 项目总览文档（当前文件）
```

---

<p align="center">
    <img src="https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black" alt="Linux">
    <img src="https://img.shields.io/badge/c++-%2300599C.svg?style=for-the-badge&logo=c%2B%2B&logoColor=white" alt="C++">
    <img src="https://img.shields.io/badge/WebSocket-010101?style=for-the-badge&logo=socketdotio&logoColor=white" alt="WebSocket">
    <img src="https://img.shields.io/badge/Shell_Script-121011?style=for-the-badge&logo=gnu-bash&logoColor=white" alt="Shell Script">
</p>

## 📊 课程成绩分析

<div style="display: flex; align-items: flex-start; gap: 20px;">
<div style="flex: 0 0 400px;">
<img src="成绩截图.png" alt="课程成绩截图" width="400px">
</div>
<div style="flex: 1;">

**评分项分析：**

- **平时分：** 作业字数少了点，应该让 AI 多干点活
- **期末分：** 综合报告页数够了
- **结论：** 报告字数越多，分数越高；建议增加代码实现和测试用例的详细描述

</div>
</div>




---
