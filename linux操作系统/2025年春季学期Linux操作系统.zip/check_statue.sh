#!/bin/bash

# 调试模式
# 注释以停用调试模式
set -x

# 指定输出编码为 UTF-8
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# 阈值设定
# 内存使用率、CPU 负载、温度阈值
MEM_THRESHOLD=80
LOAD_THRESHOLD=2.0
TEMP_THRESHOLD=70
DISK_THRESHOLD=90  # 添加磁盘使用率阈值

echo "开始系统健康检查..."
echo "-----------------------------"

# 检查磁盘使用率
for partition in $(df -h | grep '^/dev/' | awk '{print $1}'); do
    usage=$(df -h | grep $partition | awk '{print $5}' | sed 's/%//')
    used=$(df -h | grep $partition | awk '{print $3}')
    total=$(df -h | grep $partition | awk '{print $2}')
    if [ "$usage" -gt "$DISK_THRESHOLD" ]; then
        echo "⚠️  警告：分区 $partition 使用率已达 ($used/$total) $usage%"
    else
        echo "✅ 分区 $partition 使用率正常（$used/$total） $usage%"
    fi
done

# 检查内存使用率
mem_used=$(free | awk '/Mem:/ {printf("%.0f", $3/$2*100)}')
mem_used_mb=$(free -m | awk '/Mem:/ {print $3}')
mem_total_mb=$(free -m | awk '/Mem:/ {print $2}')
if [ "$mem_used" -gt "$MEM_THRESHOLD" ]; then
    echo "⚠️  内存使用率过高：($mem_used_mb/$mem_total_mb MB) $mem_used%"
else
    echo "✅ 内存使用率正常：($mem_used_mb/$mem_total_mb MB) $mem_used%"
fi

# 检查 CPU 负载
load=$(uptime | awk -F'load average:' '{print $2}' | cut -d, -f1 | sed 's/ //g')
load_int=$(echo "$load > $LOAD_THRESHOLD" | bc)
if [ "$load_int" -eq 1 ]; then
    echo "⚠️  CPU 负载过高：$load"
else
    echo "✅ CPU 负载正常：$load"
fi

# 检查温度
if command -v sensors > /dev/null 2>&1; then
    temp=$(sensors | grep 'Package id 0' | awk '{print $4}' | sed 's/+//;s/°C//')
    temp_int=$(echo "$temp > $TEMP_THRESHOLD" | bc)
    if [ "$temp_int" -eq 1 ]; then
        echo "⚠️  CPU 温度过高：$temp°C"
    else
        echo "✅ CPU 温度正常：$temp°C"
    fi
else
    echo "⚠️  未找到 sensors 命令，请安装 lm-sensors。"
fi

# 检查网络连接
ping -c 1 8.8.8.8 > /dev/null 2>&1  # 更换为 Google 公共 DNS
if [ $? -ne 0 ]; then
    echo "⚠️  网络连接异常，请检查网络设置。"
else
    echo "✅ 网络连接正常。"
fi

# 嵌套循环：持续监测内存使用率直到降到阈值以下或次数超过5次
count=0
while [ $count -lt 5 ]; do
    mem_used=$(free | awk '/Mem:/ {printf("%.0f", $3/$2*100)}')
    mem_used_mb=$(free -m | awk '/Mem:/ {print $3}')
    mem_total_mb=$(free -m | awk '/Mem:/ {print $2}')
    if [ "$mem_used" -lt "$MEM_THRESHOLD" ]; then
        echo "🎉 内存已恢复正常：($mem_used_mb/$mem_total_mb MB) $mem_used%"
        break
    else
        echo "⏳ 第 $((count+1)) 次检测：内存仍然高于阈值（$mem_used_mb/$mem_total_mb MB） $mem_used%"
    fi
    count=$((count+1))
    sleep 2
done

echo "✅ 系统健康检查完成。"