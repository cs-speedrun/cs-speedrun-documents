function ok3w_ads(id){
switch(id){
//ȫվ��������468x60
case "s001":
document.writeln("<img src=\"..\/images\/46860.gif\" width=\"468\" height=\"60\" \/>");
break;
//ȫվ�����Ҳ�250x60
case "s002":
document.writeln("<script type=\"text\/javascript\">alimama_bm_revision = \"20110916a\";alimama_bm_bid = \"25246869\";alimama_bm_width = 250;alimama_bm_height = 60;alimama_bm_xmlsrc = \"http:\/\/img.uu1001.cn\/x3\/2011-09-19\/16-09\/2011-09-19_9411bd87ac322fcbe8200ba3944965c9_0.xml\";alimama_bm_link = \"http%3A%2F%2Fujia.xaghxx.com\";alimama_bm_ds = \"\";alimama_bm_as = \"default\"<\/script><script type=\"text\/javascript\" src=\"http:\/\/img.uu1001.cn\/bmv3.js?v=20110916a\"><\/script>");
break;
//ȫվ�ͨ��960x90
case "s003":
document.writeln("<script type=\"text\/javascript\">\/*960*90��������2011-9-6*\/ var cpro_id = \'u602514\';<\/script><script src=\"http:\/\/cpro.baidu.com\/cpro\/ui\/c.js\" type=\"text\/javascript\"><\/script>");
break;
//�Ƽ�3
case "s004":
document.writeln("<script type=\"text\/javascript\">alimama_bm_revision = \"20110920\";alimama_bm_bid = \"25261424\";alimama_bm_width = 140;alimama_bm_height = 75;alimama_bm_xmlsrc = \"http:\/\/img.uu1001.cn\/x2\/2011-09-20\/10-10\/2011-09-20_4f0fb6c98660850c4fd89868131088e5_0.xml\";alimama_bm_link = \"http%3A%2F%2F\";alimama_bm_ds = \"\";alimama_bm_as = \"default\"<\/script><script type=\"text\/javascript\" src=\"http:\/\/img.uu1001.cn\/bmv3.js?v=20110920\"><\/script>");
break;
//�Ƽ�1
case "s005":
document.writeln("<script type=\"text\/javascript\">alimama_bm_revision = \"20110920\";alimama_bm_bid = \"25261572\";alimama_bm_width = 140;alimama_bm_height = 75;alimama_bm_xmlsrc = \"http:\/\/img.uu1001.cn\/x2\/2011-09-20\/10-17\/2011-09-20_803edf13828b2c077a142a1f81ea2fd3_0.xml\";alimama_bm_link = \"http%3A%2F%2Fujia.xaghxx.com\";alimama_bm_ds = \"\";alimama_bm_as = \"default\"<\/script><script type=\"text\/javascript\" src=\"http:\/\/img.uu1001.cn\/bmv3.js?v=20110920\"><\/script>");
break;
//��ҳ�в�ͨ��1
case "s006":
document.writeln("<script type=\"text\/javascript\">alimama_bm_revision = \"20110920\";alimama_bm_bid = \"25263730\";alimama_bm_width = 960;alimama_bm_height = 60;alimama_bm_xmlsrc = \"http:\/\/img.uu1001.cn\/x2\/2011-09-20\/11-39\/2011-09-20_b86a75810917b64fe6c71f636fdde8c2_0.xml\";alimama_bm_link = \"http%3A%2F%2F\";alimama_bm_ds = \"\";alimama_bm_as = \"default\"<\/script><script type=\"text\/javascript\" src=\"http:\/\/img.uu1001.cn\/bmv3.js?v=20110920\"><\/script>");
break;
//ȫվ�ײ�ͨ��
case "s007":
document.writeln("<script type=\"text\/javascript\">alimama_bm_revision = \"20110920\";alimama_bm_bid = \"25263976\";alimama_bm_width = 960;alimama_bm_height = 60;alimama_bm_xmlsrc = \"http:\/\/img.uu1001.cn\/x2\/2011-09-20\/11-49\/2011-09-20_41f63ed24fd9cc1f1cd88e4c99c24c52_0.xml\";alimama_bm_link = \"http%3A%2F%2Fem.emosons.cn%2Flist.asp%3Fid%3D6\";alimama_bm_ds = \"\";alimama_bm_as = \"default\"<\/script><script type=\"text\/javascript\" src=\"http:\/\/img.uu1001.cn\/bmv3.js?v=20110920\"><\/script>");
break;
}
}