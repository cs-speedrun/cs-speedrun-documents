def process_instructions(input_file, output_file):
    try:
        with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
            for line_number, instruction in enumerate(infile):
                # Remove any newline characters and spaces from the instruction
                instruction = instruction.strip()
                # Format the instruction as a Verilog assignment statement
                formatted_instruction = f"assign mem[{line_number}] = 32'h{instruction};\n"
                # Write the formatted instruction to the output file
                outfile.write(formatted_instruction)
        return True
    except Exception as e:
        print(f"Error processing the file: {e}")
        return False

# File names
work_dir = r"C:\Users\Desktop\Mars\\" # 修改为你的目录
out_dir = r"C:\Users\Desktop\Mars\tools\\" # 修改为你的目录
input_file = work_dir + 'inst.txt'
output_file = out_dir + 'inst_result.txt'

# Process the instructions
process_successful = process_instructions(input_file, output_file)